import RPi.GPIO as GPIO
import time

tr=[4,5]
br=[6,12]
bl=[13,16]
tl=[17,18]
bed=[19,20]
curtain=[21,22]

GPIO.setmode(GPIO.BCM)
GPIO.setup(4,GPIO.OUT)
GPIO.setup(5,GPIO.OUT)
GPIO.setup(6,GPIO.OUT)
GPIO.setup(12,GPIO.OUT)
GPIO.setup(13,GPIO.OUT)
GPIO.setup(16,GPIO.OUT)
GPIO.setup(17,GPIO.OUT)
GPIO.setup(18,GPIO.OUT)
GPIO.setup(19,GPIO.OUT)
GPIO.setup(20,GPIO.OUT)
GPIO.setup(21,GPIO.OUT)
GPIO.setup(22,GPIO.OUT)

def drive_motor(position,statue):
	if position=="tr":
		if statue==1:
			GPIO.output(tr[1],GPIO.HIGH)
			GPIO.output(tr[0],GPIO.LOW)
		if statue==0:
			GPIO.output(tr[0],GPIO.HIGH)
			GPIO.output(tr[1],GPIO.LOW)
		if statue==2:
			GPIO.output(tr[0],GPIO.LOW)
			GPIO.output(tr[1],GPIO.LOW)
	if position=="br":
		if statue==1:
			GPIO.output(br[1],GPIO.HIGH)
			GPIO.output(br[0],GPIO.LOW)
		if statue==0:
			GPIO.output(br[0],GPIO.HIGH)
			GPIO.output(br[1],GPIO.LOW)
		if statue==2:
			GPIO.output(br[0],GPIO.LOW)
			GPIO.output(br[1],GPIO.LOW)
	if position=="bl":
		if statue==1:
			GPIO.output(bl[1],GPIO.HIGH)
			GPIO.output(bl[0],GPIO.LOW)
		if statue==0:
			GPIO.output(bl[0],GPIO.HIGH)
			GPIO.output(bl[1],GPIO.LOW)
		if statue==2:
			GPIO.output(bl[0],GPIO.LOW)
			GPIO.output(bl[1],GPIO.LOW)
	if position=="tl":
		if statue==1:
			GPIO.output(tl[1],GPIO.HIGH)
			GPIO.output(tl[0],GPIO.LOW)
		if statue==0:
			GPIO.output(tl[0],GPIO.HIGH)
			GPIO.output(tl[1],GPIO.LOW)
		if statue==2:
			GPIO.output(tl[0],GPIO.LOW)
			GPIO.output(tl[1],GPIO.LOW)
	if position=="10":
		if statue==1:
			GPIO.output(bed[1],GPIO.HIGH)
			GPIO.output(bed[0],GPIO.LOW)
		if statue==0:
			GPIO.output(bed[0],GPIO.HIGH)
			GPIO.output(bed[1],GPIO.LOW)
		if statue==2:
			GPIO.output(bed[0],GPIO.LOW)
			GPIO.output(bed[1],GPIO.LOW)
	if position=="8":
		if statue==1:
			GPIO.output(curtain[1],GPIO.HIGH)
			GPIO.output(curtain[0],GPIO.LOW)
		if statue==0:
			GPIO.output(curtain[0],GPIO.HIGH)
			GPIO.output(curtain[1],GPIO.LOW)
		if statue==2:
			GPIO.output(curtain[0],GPIO.LOW)
			GPIO.output(curtain[1],GPIO.LOW)

		

if __name__=="__main__":
	drive_motor("8",1)
	time.sleep(1)
	drive_motor("8",2)
	time.sleep(3)
	drive_motor("8",0)
	time.sleep(0.1)
	drive_motor("8",2)
	GPIO.cleanup()
