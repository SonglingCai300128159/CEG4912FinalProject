import smbus
import math
import time
bus = smbus.SMBus(1)

def get_temp():
    bus.write_i2c_block_data(0x44,0x2c,[0x06])
    time.sleep(0.1)
    data = bus.read_i2c_block_data(0x44,0x00,6)

    st = data[0]*16*16+data[1]
    temperature = 175*(st/(pow(2,16)-1))-45

    srh = data[3]*16*16+data[4];
    humidity = 125*(srh/(pow(2,16)-1))-6

    return temperature,humidity

if __name__=="__main__":
    data = get_temp()
    print(data)
