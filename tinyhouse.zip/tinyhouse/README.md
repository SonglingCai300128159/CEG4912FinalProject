# CEG4912FinalProject
CEG4912 F00 GROUP 5 Final Project

make sure react is installed on local drive.

npm commands needed:

npm install

npm install bootstrap

npm install -g create-react-app

npm install react-router-dom

npm install react-icons

npm install styled-components

npm install rsuite

npm install socket.io-client

!!!!!for server, before run app.py in serverdriver, add "pip install Flask Flask-SocketIO Flask-CORS
" in terminal

pip install opencv-python numpy

use npm start to boot local webapp


