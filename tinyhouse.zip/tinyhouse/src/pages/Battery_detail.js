import React from 'react';
function Battery_detail() {
  return (
    <div>
      <h1>Battery level!</h1>
    </div>
  )
}

export default Battery_detail
