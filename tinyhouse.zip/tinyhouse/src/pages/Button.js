import React, { useState } from 'react';
import '../pages/Button.css';

const Button = ({ motor, state, children }) => {
  const [isActive, setIsActive] = useState(false); // State to manage active state of the button

  const sendMotorState = async (state) => {
    try {
      const response = await fetch(`http://localhost:5000/api/control-motor/${motor}${state}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error(`Error sending state ${state} for motor ${motor}:`, error);
    }
  };

  const handlePress = () => {
    setIsActive(true); // Set button as active
    sendMotorState(state);
  };

  const handleRelease = () => {
    setIsActive(false); // Reset button to inactive
    sendMotorState(2);
  };

  // Dynamically assign classes based on the isActive state
  const buttonClasses = isActive ? "custom-button active" : "custom-button";

  return (
    <button
      className={buttonClasses}
      onMouseDown={handlePress}
      onMouseUp={handleRelease}
      onTouchStart={handlePress}
      onTouchEnd={handleRelease}
      onTouchCancel={handleRelease}
    >
      {children}
    </button>
  );
};

export default Button;
