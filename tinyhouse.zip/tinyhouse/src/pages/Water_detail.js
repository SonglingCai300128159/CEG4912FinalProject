import React from 'react'

function WATER_DETAIL() {
  return (
    <div>
      <h1>Water tank level!</h1>
    </div>
  )
}

export default WATER_DETAIL
