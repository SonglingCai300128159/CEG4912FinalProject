import React, { useState, useEffect } from 'react';
import './ENVIRONMENT_MAIN.css';
import tem_icon from './Assets/icons-temperature-48.png';
import humidity_icon from './Assets/icons-humidity-50.png';
import air_icon from './Assets/icons8-air-50.png';
import { useData } from './DataContext';

const ENVIRONMENT_MAIN = () => {
    const { temperatureData, humidityData, pm10Data, pm25Data } = useData();

    return(
        
            <div className='container'>
                <div className='env'>
                    <div className='temperature'>
                        <img src={tem_icon} alt='' className='icon' />
                        <div className='temperature_data'>
                            <h4 className='text'>Temp: </h4>
                            <h4 className='data'>{temperatureData}</h4>
                        </div>
                    </div>
                    <div className='humidity'>
                        <img src={humidity_icon} alt='' className='icon'/>
                        <div className='humidity_data'>
                            <h4 className='text'>Humidity: </h4>
                            <h4 className='data'>{humidityData}</h4>
                        </div>
                    </div>
                    <div className='air_condition'>
                        <img src={air_icon} alt='' className='icon' />
                        <div className='PM10_data'>
                            <h4 className='text'>PM10: </h4>
                            <h4 className='data'>{pm10Data}</h4>
                        </div>
                        <div className='PM25_data'>
                            <h4 className='text'>PM2.5: </h4>
                            <h4 className='data'>{pm25Data}</h4>
                        </div>
                    </div>
                </div>

            </div>
            
    )
}

export default ENVIRONMENT_MAIN;