import Form from 'react-bootstrap/Form';

function SwitchExample() {
  return (
    <Form>
      <Form.Switch 
        type="switch"
        id="custom-switch"
        label=""
      />
    </Form>
  );
}

export default SwitchExample;