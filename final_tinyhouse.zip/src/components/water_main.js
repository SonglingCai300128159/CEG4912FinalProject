import { useState } from 'react';
import React from 'react';
import'./watermain.css';
import { useData } from './DataContext';
const WATER_MAIN = () =>{
    //const [percentage, setPercentage] = useState(35);
    //const [filled, setFilled]= useState(35);
    const { BlackwaterPercentage } = useData(50);
    return (
      <div id='watercmp'>
       
       <h4 className='BWTitle'>Black Water</h4>
        <div id='watercontent'>
            <div className="watercircle" style={{
            background: `linear-gradient(#84adc8 ${100-BlackwaterPercentage}%, #1f3b6e ${100-BlackwaterPercentage+10}%)`,
            }}>
            <p className="circle-text">{BlackwaterPercentage}%</p>
            </div>
        </div>
        
      </div>
    );

    
};

export default WATER_MAIN;