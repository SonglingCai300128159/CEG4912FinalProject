import { useState } from 'react';
import React from 'react';
import './watermain.css';
import { useData } from './DataContext';
import Button from 'react-bootstrap/Button';

const WATER_MAIN2 = () => {
    const { CleanwaterPercentage } = useData(50);

    const handleAdjustClick = () => {
        fetch('http://localhost:5000/api/water_adjust', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ value: 1 }), 
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    };

    return (
      <div id='watercmp'>
        <h4 className='BWTitle'>Clean Water</h4>
        <div id='watercontent'>
            <div className="watercircle" style={{
                background: `linear-gradient(#84adc8 ${100-CleanwaterPercentage}%, #1f3b6e ${100-CleanwaterPercentage+10}%)`,
            }}>
                <p className="circle-text">{CleanwaterPercentage}%</p>
            </div>
            <Button onClick={handleAdjustClick}><p>Reset</p></Button>{' '}
        </div>
      </div>
    );
};

export default WATER_MAIN2;
