import time
import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

def get_waterdepth(channel):

    i2c = busio.I2C(board.SCL, board.SDA)
    ads = ADS.ADS1115(i2c,address=0x49)
    
    if channel==0:
        chan = AnalogIn(ads, ADS.P0)
    if channel==1:
        chan = AnalogIn(ads, ADS.P1)
    if channel==2:
        chan = AnalogIn(ads, ADS.P2)
    if channel==3:
        chan = AnalogIn(ads, ADS.P3)

    return chan.voltage

if __name__=="__main__":
    print(get_waterdepth(3))


