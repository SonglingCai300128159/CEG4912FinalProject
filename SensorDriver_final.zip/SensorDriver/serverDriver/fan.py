import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setup(23,GPIO.OUT)
p = GPIO.PWM(23,100)
p.start(0)

def fanDriver(vl):
    p.ChangeDutyCycle(vl)
    return 0

if __name__=="__main__":
    fanDriver(5)
    time.sleep(2)
    fanDriver(30)
    time.sleep(2)
    fanDriver(80)
    time.sleep(2)
    p.stop
    GPIO.cleanup()

