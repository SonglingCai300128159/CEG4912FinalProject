import serial
import time

ser = serial.Serial()

ser.port='/dev/ttyAMA0'
ser.baudrate=9600
ser.bytesize=8
ser.stopbits=1
ser.parity="N"
ser.open()
raw=[]

def get_pm25_data():
    for i in range(10):
        data=int.from_bytes(ser.read(),byteorder='big',signed=False)
        raw.append(data)

    PM25=(raw[3]*256+raw[2])/10.0
    PM10=(raw[5]*256+raw[4])/10.0
    return PM25,PM10

if __name__=="__main__":
    print(get_pm25_data())
