import serial
import time

ser = serial.Serial()

ser.port='/dev/ttyUSB0'
ser.baudrate=9600
ser.bytesize=8
ser.stopbits=1
ser.parity="N"
ser.open()

def control_relay(port,statue):
    if port==0:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x00, 0xff, 0x00, 0x8c, 0x3a])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x00, 0x00, 0x00, 0xcd, 0xca])
            ser.write(input)
    if port==1:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x01, 0xff, 0x00, 0xdd, 0xfa])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x01, 0x00, 0x00, 0x9c, 0x0a])
            ser.write(input)
    if port==2:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x02, 0xff, 0x00, 0x2d, 0xfa])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x02, 0x00, 0x00, 0x6c, 0x0a])
            ser.write(input)
    if port==3:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x03, 0xff, 0x00, 0x7c, 0x3a])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x03, 0x00, 0x00, 0x3d, 0xca])
            ser.write(input)
    if port==4:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x04, 0xff, 0x00, 0xcd, 0xfb])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x04, 0x00, 0x00, 0x8c, 0x0b])
            ser.write(input)
    if port==5:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x05, 0xff, 0x00, 0x9c, 0x3b])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x05, 0x00, 0x00, 0xdd, 0xcb])
            ser.write(input)
    if port==6:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x06, 0xff, 0x00, 0x6c, 0x3b])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x06, 0x00, 0x00, 0x2d, 0xcb])
            ser.write(input)
    if port==7:
        if statue==1:
            input = bytes([0x01, 0x05, 0x00, 0x07, 0xff, 0x00, 0x3d, 0xfb])
            ser.write(input)
        if statue==0:
            input = bytes([0x01, 0x05, 0x00, 0x07, 0x00, 0x00, 0x7c, 0x0b])
            ser.write(input)

def relay_initial():
    input = bytes([0x01, 0x0f, 0x00, 0x00, 0x00, 0x08, 0x01, 0x00, 0xfe, 0x95])
    ser.write(input)



if __name__=="__main__":
    control_relay(0,1)
    time.sleep(0.1)
    control_relay(1,1)
    time.sleep(0.1)
    control_relay(2,1)
    time.sleep(0.1)
    control_relay(3,1)
    time.sleep(0.1)
    control_relay(4,1)
    time.sleep(0.1)
    control_relay(5,1)
    time.sleep(0.1)
    control_relay(6,1)
    time.sleep(0.1)
    control_relay(7,1)
    time.sleep(2)
    relay_initial()
