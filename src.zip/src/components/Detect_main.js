import React, { useState, useEffect } from 'react';
// Import other required components and assets as before
import './ENVIRONMENT_MAIN.css';
import { useData } from './DataContext';
import cam_icon from './Assets/icons8-camera-64.png'
import ic_warning from './Assets/icons8-danger-96.png'
const Detect_main = () => {
    const [status, setStatus] = useState('inactive'); // 初始状态设置为'inactive'

    useEffect(() => {
        // 状态检查函数
        const checkStatus = async () => {
            try {
                const response = await fetch('http://10.42.0.1:5000/api/cam_status');
                const data = await response.json();
                if (data.cam_status === 'running') {
                    setStatus('Active');
                } else {
                    setStatus('Inactive');
                }
            } catch (error) {
                console.error('Status check failed:', error);
                setStatus('Inactive');
            }
        };

        checkStatus();

        // 你可以设置一个定时器来定期检查状态
         const intervalId = setInterval(checkStatus, 10000); // 每5秒检查一次

        // 清理函数，当组件卸载时调用
        // return () => clearInterval(intervalId);

    }, []);
    const statusStyle = {
        color: status === 'Active' ? 'green' : 'red',
    };
    return (
        <div className='container_cam'>
            <div id='monitor_title'>
                <h3>Surveillance</h3>
            </div>
            <div id='monitor_content'>
                <img src={cam_icon} alt='' className='icon' />
            </div>
            <div id='warning'>
                <img src={ic_warning} id='img_warning' alt='' />
                <h3 >Status:</h3><h3 style={statusStyle}>{status}</h3>{/* Display the status */}
            </div>
            
        </div>
    );
}

export default Detect_main;
