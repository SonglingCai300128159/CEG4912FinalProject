import React, { useState, useEffect } from 'react';
import '../pages/Enviroment_detail.css';

const Flowrate = () => {
    const [Power, setPower] = useState(0);

    useEffect(() => {
        const fetchInitialStatus = async () => {
            try {
                const response = await fetch(`http://localhost:5000/api/fan_power/${Power}`);
                const data = await response.json();
                setPower(data.fanpwm);
            } catch (error) {
                console.error('Error fetching initial fan power:', error);
            }
        };

        fetchInitialStatus();
    }, []);

    const handleValue = async () => {
        try {
            const response = await fetch(`http://localhost:5000/api/fan_power/${Power}`, {
                method: 'POST',
            });
            const data = await response.json();
            setPower(data.fanpwm);
        } catch (error) {
            console.error('Error setting fan power:', error);
        }
    };

    // Use this function to update the power state as the slider moves
    const handleChange = (ev) => {
        setPower(ev.target.value);
    };

    return (
        <>  
            <h3 id='powertext'> {Power} % Power</h3>
            <input
                type="range"
                orient="horizontal"
                min="0"
                max="100"
                step="1"
                value={Power}
                onChange={handleChange} // Use handleChange to continuously update the power
                onMouseUp={handleValue} // Trigger handleValue when mouse is released
                onTouchEnd={handleValue} // Trigger handleValue when touch interaction ends
            />
            
            
        </>
    );
};

export default Flowrate;
