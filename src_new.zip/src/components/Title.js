function TITLE() {
    return (
        <h1>Net Zero Tiny House</h1>    
    );
};
export default TITLE;