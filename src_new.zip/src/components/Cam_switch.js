import React from 'react';
import { useData } from './DataContext'; // Ensure this path is correct based on your file structure

const Cam_switch = () => {
  const { isCameraOn, toggleCamera } = useData();

  return (
    <button onClick={toggleCamera}>
      {isCameraOn ? 'Turn Camera Off' : 'Turn Camera On'}
    </button>
  );
};

export default Cam_switch;
